package com.example.eventtracker_matteorusso;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

public class UserDatabaseHelper extends SQLiteOpenHelper {

    public static final String USER_TABLE_NAME = "users";
    public static final String USER_COL_ID = "ID";
    public static final String USER_COL_USERNAME = "username";
    public static final String USER_COL_PASSWORD = "password";
    public static final String USER_COL_PHONE = "phone";

    public static final String EVENT_TABLE_NAME = "events";
    public static final String EVENT_COL_ID = "ID";
    public static final String EVENT_COL_TITLE = "title";
    public static final String EVENT_COL_DATE = "date";
    public static final String EVENT_COL_TIME = "time";
    public static final String EVENT_COL_DESCRIPTION = "description";
    public static final String EVENT_COL_USERNAME = "username";

    public UserDatabaseHelper(Context context) {
        super(context, USER_TABLE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUserTable = "CREATE TABLE " + USER_TABLE_NAME + " (" + USER_COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                USER_COL_USERNAME + " TEXT, " + USER_COL_PASSWORD + " TEXT, " + USER_COL_PHONE + " TEXT)";
        db.execSQL(createUserTable);

        String createEventTable = "CREATE TABLE " + EVENT_TABLE_NAME + " (" + EVENT_COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                EVENT_COL_TITLE + " TEXT, " + EVENT_COL_DATE + " TEXT, " + EVENT_COL_TIME + " TEXT, " + EVENT_COL_DESCRIPTION + " TEXT, " + EVENT_COL_USERNAME + " TEXT)";
        db.execSQL(createEventTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + EVENT_TABLE_NAME);
        onCreate(db);
    }

    public boolean addUser(String username, String password, String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(USER_COL_USERNAME, username);
        contentValues.put(USER_COL_PASSWORD, password);
        contentValues.put(USER_COL_PHONE, phone);

        long result = db.insert(USER_TABLE_NAME, null, contentValues);
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {USER_COL_ID};
        String selection = USER_COL_USERNAME + " = ?" + " AND " + USER_COL_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};
        Cursor cursor = db.query(USER_TABLE_NAME, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();

        return count > 0;
    }

    public boolean checkUser(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {USER_COL_ID};
        String selection = USER_COL_USERNAME + " = ?";
        String[] selectionArgs = {username};
        Cursor cursor = db.query(USER_TABLE_NAME, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();

        return count > 0;
    }

    public String getPhoneNumber(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {USER_COL_PHONE};
        String selection = USER_COL_USERNAME + " = ?";
        String[] selectionArgs = {username};
        Cursor cursor = db.query(USER_TABLE_NAME, columns, selection, selectionArgs, null, null, null);
        String phoneNumber = null;
        if (cursor.moveToFirst()) {
            @SuppressLint("Range") String number = cursor.getString(cursor.getColumnIndex(USER_COL_PHONE));
            phoneNumber = number;
        }
        cursor.close();
        return phoneNumber;
    }

    public boolean addEvent(String title, String date, String time, String description, String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(EVENT_COL_TITLE, title);
        contentValues.put(EVENT_COL_DATE, date);
        contentValues.put(EVENT_COL_TIME, time);
        contentValues.put(EVENT_COL_DESCRIPTION, description);
        contentValues.put(EVENT_COL_USERNAME, username);

        long result = db.insert(EVENT_TABLE_NAME, null, contentValues);
        return result != -1;
    }

    public Cursor getEvents(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {EVENT_COL_ID, EVENT_COL_TITLE, EVENT_COL_DATE, EVENT_COL_TIME, EVENT_COL_DESCRIPTION};
        String selection = EVENT_COL_USERNAME + " = ?";
        String[] selectionArgs = {username};
        return db.query(EVENT_TABLE_NAME, columns, selection, selectionArgs, null, null, null);
    }

    public Cursor getEventsForDate(String username, String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {EVENT_COL_ID, EVENT_COL_TITLE, EVENT_COL_DATE, EVENT_COL_TIME, EVENT_COL_DESCRIPTION};
        String selection = EVENT_COL_USERNAME + " = ? AND " + EVENT_COL_DATE + " = ?";
        String[] selectionArgs = {username, date};
        return db.query(EVENT_TABLE_NAME, columns, selection, selectionArgs, null, null, EVENT_COL_TIME);
    }

    public Cursor getFutureEvents(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {EVENT_COL_ID, EVENT_COL_TITLE, EVENT_COL_DATE, EVENT_COL_TIME, EVENT_COL_DESCRIPTION};
        String selection = EVENT_COL_USERNAME + " = ? AND " + EVENT_COL_DATE + " >= ?";
        String[] selectionArgs = {username, LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))};
        return db.query(EVENT_TABLE_NAME, columns, selection, selectionArgs, null, null, EVENT_COL_DATE + ", " + EVENT_COL_TIME);
    }

    public Map<Integer, Integer> getEventCountsForMonth(String username, String month) {
        Map<Integer, Integer> eventCounts = new HashMap<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {EVENT_COL_DATE};
        String selection = EVENT_COL_USERNAME + " = ? AND " + EVENT_COL_DATE + " LIKE ?";
        String[] selectionArgs = {username, month + "%"};
        Cursor cursor = db.query(EVENT_TABLE_NAME, columns, selection, selectionArgs, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String date = cursor.getString(cursor.getColumnIndex(EVENT_COL_DATE));
                int day = LocalDate.parse(date).getDayOfMonth();
                eventCounts.put(day, eventCounts.getOrDefault(day, 0) + 1);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return eventCounts;
    }

    public boolean updateEvent(String id, String title, String date, String time, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(EVENT_COL_TITLE, title);
        contentValues.put(EVENT_COL_DATE, date);
        contentValues.put(EVENT_COL_TIME, time);
        contentValues.put(EVENT_COL_DESCRIPTION, description);
        long result = db.update(EVENT_TABLE_NAME, contentValues, EVENT_COL_ID + " = ?", new String[]{id});
        return result != -1;
    }

    public Integer deleteEvent(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(EVENT_TABLE_NAME, "ID = ?", new String[]{id});
    }

    public String getEventId(String username, String title, String date, String time24) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {EVENT_COL_ID};
        String selection = EVENT_COL_USERNAME + " = ? AND " + EVENT_COL_TITLE + " = ? AND " + EVENT_COL_DATE + " = ? AND " + EVENT_COL_TIME + " = ?";
        String[] selectionArgs = {username, title, date, time24};
        Cursor cursor = db.query(EVENT_TABLE_NAME, columns, selection, selectionArgs, null, null, null);
        String eventId = null;
        if (cursor.moveToFirst()) {
            @SuppressLint("Range") String id = cursor.getString(cursor.getColumnIndex(EVENT_COL_ID));
            eventId = id;
        }
        cursor.close();
        return eventId;
    }

    public boolean updatePhoneNumber(String username, String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(USER_COL_PHONE, phone);
        long result = db.update(USER_TABLE_NAME, contentValues, USER_COL_USERNAME + " = ?", new String[]{username});
        return result != -1;
    }
}
