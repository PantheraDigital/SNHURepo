package com.example.eventtracker_matteorusso;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.Settings;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class NotificationScheduler {

    public static final int PERMISSION_REQUEST_CODE = 1;

    public static boolean checkPermissions(Activity activity) {
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_CODE);
            return false;
        }

        AlarmManager alarmManager = (AlarmManager) activity.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null && !alarmManager.canScheduleExactAlarms()) {
            Toast.makeText(activity, "Please allow setting exact alarms for notifications.", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
            activity.startActivity(intent);
            return false;
        }

        return true;
    }


    public static void scheduleAlarm(Context context, UserDatabaseHelper dbHelper, String userName, String id, String title, String date, String time) {
        String phoneNumber = dbHelper.getPhoneNumber(userName);
        if (phoneNumber == null) {
            return;
        }

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, NotificationReceiver.class);
        intent.putExtra("EVENT_TITLE", title);
        intent.putExtra("PHONE_NUMBER", phoneNumber);

        LocalDate eventDate = LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        LocalTime eventTime = LocalTime.parse(time, DateTimeFormatter.ofPattern("HH:mm"));

        long triggerTime = eventDate.atTime(eventTime).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        int pendingIntentId = Integer.parseInt(id);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, pendingIntentId, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        if (alarmManager != null) {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent);
        }
    }

    public static void cancelAlarm(Context context, UserDatabaseHelper dbHelper, String userName, String id, String title) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, NotificationReceiver.class);
        String phoneNumber = dbHelper.getPhoneNumber(userName);
        intent.putExtra("EVENT_TITLE", title);
        intent.putExtra("PHONE_NUMBER", phoneNumber);
        int pendingIntentId = Integer.parseInt(id);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, pendingIntentId, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        if (alarmManager != null) {
            alarmManager.cancel(pendingIntent);
        }
    }

    public static void scheduleAllFutureEvents(Context context, UserDatabaseHelper dbHelper, String userName) {
        Cursor cursor = dbHelper.getFutureEvents(userName);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String id = cursor.getString(cursor.getColumnIndex(UserDatabaseHelper.EVENT_COL_ID));
                @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex(UserDatabaseHelper.EVENT_COL_TITLE));
                @SuppressLint("Range") String date = cursor.getString(cursor.getColumnIndex(UserDatabaseHelper.EVENT_COL_DATE));
                @SuppressLint("Range") String time = cursor.getString(cursor.getColumnIndex(UserDatabaseHelper.EVENT_COL_TIME));

                scheduleAlarm(context, dbHelper, userName, id, title, date, time);
            } while (cursor.moveToNext());
        }
        cursor.close();
        Toast.makeText(context, "Notifications ON", Toast.LENGTH_SHORT).show();
    }

    public static void cancelAllFutureEvents(Context context, UserDatabaseHelper dbHelper, String userName) {
        Cursor cursor = dbHelper.getFutureEvents(userName);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String id = cursor.getString(cursor.getColumnIndex(UserDatabaseHelper.EVENT_COL_ID));
                @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex(UserDatabaseHelper.EVENT_COL_TITLE));
                cancelAlarm(context, dbHelper, userName, id, title);
            } while (cursor.moveToNext());
        }
        cursor.close();
        Toast.makeText(context, "Notifications OFF", Toast.LENGTH_SHORT).show();
    }
}
