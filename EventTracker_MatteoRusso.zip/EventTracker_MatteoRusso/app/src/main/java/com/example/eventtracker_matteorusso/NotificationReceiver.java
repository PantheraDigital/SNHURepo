package com.example.eventtracker_matteorusso;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;

public class NotificationReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String eventTitle = intent.getStringExtra("EVENT_TITLE");
        String phoneNumber = intent.getStringExtra("PHONE_NUMBER");

        try {
            SmsManager smsManager = context.getSystemService(SmsManager.class);
            smsManager.sendTextMessage(phoneNumber, null, "Event Reminder: " + eventTitle, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
