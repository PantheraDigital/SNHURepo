package com.example.eventtracker_matteorusso;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.widget.PopupMenu;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements CalendarAdapter.OnItemListener {

    private static final String SELECTED_DATE = "SELECTED_DATE";
    private static final String CALENDAR_DATE = "CALENDAR_DATE";
    private static final String PREFS_NAME = "EventTrackerPrefs";
    private static final String NOTIFICATIONS_ON_KEY = "notifications_on";

    private LocalDate selectedDate;
    private LocalDate calendarDate;

    private View divider;
    private TextView selectedDayText;
    private TextView monthYearText;
    private RecyclerView calendarRecyclerView;
    private TextView userNameText;
    private FloatingActionButton addEventButton;
    private LinearLayout dayEventsList;
    private UserDatabaseHelper dbHelper;
    private boolean notificationsOn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        initWidgets();
        dbHelper = new UserDatabaseHelper(this);

        Intent intent = getIntent();
        String userName = intent.getStringExtra("USER_NAME");
        userNameText.setText(userName);

        String notificationsOnKey = NOTIFICATIONS_ON_KEY + "_" + userName;
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        notificationsOn = prefs.getBoolean(notificationsOnKey, false);

        ConstraintLayout mainLayout = findViewById(R.id.main);
        ViewCompat.setOnApplyWindowInsetsListener(mainLayout, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, v.getPaddingTop(), systemBars.right, v.getPaddingBottom());
            return insets;
        });
        AppBarLayout appBar = findViewById(R.id.appbar);
        ViewCompat.setOnApplyWindowInsetsListener(appBar, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(v.getPaddingLeft(), systemBars.top, v.getPaddingRight(), v.getPaddingBottom());
            return insets;
        });
        ConstraintLayout fab = findViewById(R.id.fabHolder);
        ViewCompat.setOnApplyWindowInsetsListener(fab, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(v.getPaddingLeft(), v.getPaddingTop(), v.getPaddingRight(), systemBars.bottom);
            return insets;
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        addEventButton.setOnClickListener(v -> {
            Intent addEventIntent = new Intent(MainActivity.this, EventDetails.class);
            addEventIntent.putExtra("USER_NAME", userName);
            addEventIntent.putExtra("SELECTED_DATE", selectedDate.toString());
            startActivity(addEventIntent);
        });

        if (savedInstanceState != null) {
            selectedDate = savedInstanceState.getSerializable(SELECTED_DATE, LocalDate.class);
            calendarDate = savedInstanceState.getSerializable(CALENDAR_DATE, LocalDate.class);
        } else {
            selectedDate = LocalDate.now();
            calendarDate = LocalDate.now();
        }

        setMonthView();
        updateSelectedDayText(selectedDate);
        updateDayEventsList(selectedDate);


        divider.setOnTouchListener(new View.OnTouchListener() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_MOVE) {
                    ConstraintLayout.LayoutParams params = (ConstraintLayout.LayoutParams) v.getLayoutParams();
                    float y = event.getRawY();
                    int[] location = new int[2];
                    mainLayout.getLocationOnScreen(location);
                    int parentTop = location[1];
                    float bias = (y - parentTop) / mainLayout.getHeight();
                    if (bias < 0.2f) {
                        bias = 0.2f;
                    }
                    if (bias > 0.8f) {
                        bias = 0.8f;
                    }
                    params.verticalBias = bias;
                    v.setLayoutParams(params);
                }
                return true;
            }
        });
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable(SELECTED_DATE, selectedDate);
        outState.putSerializable(CALENDAR_DATE, calendarDate);
    }

    @Override
    public void onItemClick(int position, String dayText) {
        if (!dayText.isEmpty()){
            selectedDate = calendarDate.withDayOfMonth(Integer.parseInt(dayText));
            updateSelectedDayText(selectedDate);
            updateDayEventsList(selectedDate);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        setMonthView();
        updateDayEventsList(selectedDate);
    }


    @SuppressLint("RestrictedApi")
    public void showMenu(View view) {
        PopupMenu popup = new PopupMenu(this, view);
        popup.getMenuInflater().inflate(R.menu.main_menu, popup.getMenu());

        MenuItem notificationToggle = popup.getMenu().findItem(R.id.action_notification_toggle);
        if (notificationsOn) {
            notificationToggle.setTitle(R.string.action_notifications_on);
            notificationToggle.setIcon(R.drawable.outline_notifications_active_24);
        } else {
            notificationToggle.setTitle(R.string.action_notifications_off);
            notificationToggle.setIcon(R.drawable.outline_notifications_off_24);
        }

        popup.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.action_notification_toggle) {
                String userName = userNameText.getText().toString();

                if (!notificationsOn) {
                    if (NotificationScheduler.checkPermissions(this)) {
                        String phoneNumber = dbHelper.getPhoneNumber(userName);
                        if (phoneNumber == null || phoneNumber.isEmpty()) {
                            promptForPhoneNumber(item);
                        } else {
                            setNotificationsOn(item);
                            NotificationScheduler.scheduleAllFutureEvents(this, dbHelper, userName);
                        }
                    }
                } else {
                    setNotificationsOff(item);
                    NotificationScheduler.cancelAllFutureEvents(this, dbHelper, userName);
                }
                return true;
            }
            if (item.getItemId() == R.id.action_logout) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
                return true;
            }
            return false;
        });

        if (popup.getMenu() instanceof MenuBuilder) {
            MenuBuilder menuBuilder = (MenuBuilder) popup.getMenu();
            menuBuilder.setOptionalIconsVisible(true);
        }

        popup.show();
    }


    private void initWidgets() {
        calendarRecyclerView = findViewById(R.id.calendarRecyclerView);
        monthYearText = findViewById(R.id.monthYear);
        divider = findViewById(R.id.divider);
        selectedDayText = findViewById(R.id.selectedDay);
        userNameText = findViewById(R.id.userName);
        addEventButton = findViewById(R.id.addEventButton);
        dayEventsList = findViewById(R.id.dayEventsList);
    }

    private void setMonthView() {
        monthYearText.setText(calendarDate.format(DateTimeFormatter.ofPattern("MMMM yyyy")));
        ArrayList<String> daysInMonth = daysInMonthArray(calendarDate);

        String userName = userNameText.getText().toString();
        String month = calendarDate.format(DateTimeFormatter.ofPattern("yyyy-MM"));
        Map<Integer, Integer> eventCounts = dbHelper.getEventCountsForMonth(userName, month);

        CalendarAdapter calendarAdapter = new CalendarAdapter(daysInMonth, this, eventCounts);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(), 7);
        calendarRecyclerView.setLayoutManager(layoutManager);
        calendarRecyclerView.setAdapter(calendarAdapter);
    }

    private ArrayList<String> daysInMonthArray(LocalDate date) {
        ArrayList<String> daysInMonthArray = new ArrayList<>();
        YearMonth yearMonth = YearMonth.from(date);
        int daysInMonth = yearMonth.lengthOfMonth();

        LocalDate firstOfMonth = date.withDayOfMonth(1);
        int dayOfWeek = firstOfMonth.getDayOfWeek().getValue();
        int offset = dayOfWeek == 7 ? 0 : dayOfWeek;

        for (int i = 1; i <= 42; i++){
            if (i <= offset || i > daysInMonth + offset) {
                daysInMonthArray.add("");
            } else {
                daysInMonthArray.add(String.valueOf(i - offset));
            }
        }

        return daysInMonthArray;
    }


    private void updateSelectedDayText(LocalDate date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d");
        selectedDayText.setText(date.format(formatter));
    }

    private void updateDayEventsList(LocalDate date) {
        dayEventsList.removeAllViews();
        String userName = userNameText.getText().toString();
        String dateString = date.toString();

        Cursor cursor = dbHelper.getEventsForDate(userName, dateString);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String id = cursor.getString(cursor.getColumnIndex(UserDatabaseHelper.EVENT_COL_ID));
                @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex(UserDatabaseHelper.EVENT_COL_TITLE));
                @SuppressLint("Range") String time = cursor.getString(cursor.getColumnIndex(UserDatabaseHelper.EVENT_COL_TIME));
                @SuppressLint("Range") String description = cursor.getString(cursor.getColumnIndex(UserDatabaseHelper.EVENT_COL_DESCRIPTION));

                LayoutInflater inflater = LayoutInflater.from(this);
                View eventView = inflater.inflate(R.layout.event_details, dayEventsList, false);

                TextView titleTextView = eventView.findViewById(R.id.eventTitleTextView);
                TextView timeTextView = eventView.findViewById(R.id.eventTimeTextView);
                TextView descriptionTextView = eventView.findViewById(R.id.eventDescriptionTextView);

                titleTextView.setText(title);
                try {
                    LocalTime time24 = LocalTime.parse(time, DateTimeFormatter.ofPattern("HH:mm"));
                    timeTextView.setText(time24.format(DateTimeFormatter.ofPattern("h:mm a", Locale.getDefault())));
                } catch (Exception e) {
                    timeTextView.setText(time);
                }
                descriptionTextView.setText(description);

                eventView.setOnClickListener(v -> {
                    Intent intent = new Intent(MainActivity.this, EventDetails.class);
                    intent.putExtra("USER_NAME", userName);
                    intent.putExtra("SELECTED_DATE", selectedDate.toString());
                    intent.putExtra("EVENT_ID", id);
                    intent.putExtra("EVENT_TITLE", title);
                    intent.putExtra("EVENT_TIME", time);
                    intent.putExtra("EVENT_DESCRIPTION", description);
                    startActivity(intent);
                });

                dayEventsList.addView(eventView);
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    public void previousMonthAction(View view) {
        calendarDate = calendarDate.minusMonths(1);
        setMonthView();
    }

    public void nextMonthAction(View view) {
        calendarDate = calendarDate.plusMonths(1);
        setMonthView();
    }

    private void setNotificationsOn(MenuItem item) {
        String userName = userNameText.getText().toString();
        String notificationsOnKey = NOTIFICATIONS_ON_KEY + "_" + userName;

        notificationsOn = true;
        SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
        editor.putBoolean(notificationsOnKey, true);
        editor.apply();
        if (item != null) {
            item.setTitle(R.string.action_notifications_on);
            item.setIcon(R.drawable.outline_notifications_active_24);
        }
    }

    private void setNotificationsOff(MenuItem item) {
        String userName = userNameText.getText().toString();
        String notificationsOnKey = NOTIFICATIONS_ON_KEY + "_" + userName;

        notificationsOn = false;
        SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
        editor.putBoolean(notificationsOnKey, false);
        editor.apply();
        if (item != null) {
            item.setTitle(R.string.action_notifications_off);
            item.setIcon(R.drawable.outline_notifications_off_24);
        }
    }

    private void promptForPhoneNumber(MenuItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Phone Number");
        builder.setMessage("Please enter your phone number to receive notifications.");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_PHONE);
        builder.setView(input);

        builder.setPositiveButton("OK", (dialog, which) -> {
            String phoneNumber = input.getText().toString().trim();
            String userName = userNameText.getText().toString();
            if (!phoneNumber.isEmpty()) {
                dbHelper.updatePhoneNumber(userName, phoneNumber);
                setNotificationsOn(item);
            } else {
                setNotificationsOff(item);
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> {
            setNotificationsOff(item);
            dialog.cancel();
        });

        builder.setOnCancelListener(dialog -> setNotificationsOff(item));

        builder.show();
    }

}
