package com.example.eventtracker_matteorusso;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Map;

public class CalendarAdapter extends RecyclerView.Adapter<CalendarViewHolder>{
    private final ArrayList<String> daysOfMonth;
    private final OnItemListener onItemListener;
    private final Map<Integer, Integer> eventCounts;

    public CalendarAdapter(ArrayList<String> daysOfMonth, OnItemListener onItemListener, Map<Integer, Integer> eventCounts) {
        this.daysOfMonth = daysOfMonth;
        this.onItemListener = onItemListener;
        this.eventCounts = eventCounts;
    }

    @NonNull
    @Override
    public CalendarViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.calendar_cell, parent, false);
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        layoutParams.height = (int) (parent.getHeight() / 6.2f);
        view.setLayoutParams(layoutParams);
        return new CalendarViewHolder(view, onItemListener);
    }

    @Override
    public void onBindViewHolder(@NonNull CalendarViewHolder holder, int position) {
        String dayText = daysOfMonth.get(position);
        holder.dayOfMonth.setText(dayText);
        holder.cellDayEvents.removeAllViews();

        if (!dayText.isEmpty()) {
            int day = Integer.parseInt(dayText);
            if (eventCounts.containsKey(day)) {
                int eventCount = eventCounts.get(day);
                int indicators = Math.min(eventCount, 5);
                LayoutInflater inflater = LayoutInflater.from(holder.itemView.getContext());
                for (int i = 0; i < indicators; i++) {
                    View eventIndicator = inflater.inflate(R.layout.event_indicator, holder.cellDayEvents, false);
                    holder.cellDayEvents.addView(eventIndicator);
                }
            }
        }
    }

    @Override
    public int getItemCount() {
        return daysOfMonth.size();
    }

    public interface OnItemListener {
        void onItemClick(int position, String dayText);
    }
}
