package com.example.eventtracker_matteorusso;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class EventDetails extends AppCompatActivity {

    private static final String TIME_PREFS_NAME = "TimePrefs";
    private static final String NOTIFICATION_PREFS_NAME = "EventTrackerPrefs";
    private static final String IS_24_HOUR = "is24Hour";
    private static final String NOTIFICATIONS_ON_KEY = "notifications_on";
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private final DateTimeFormatter timeFormatter24 = DateTimeFormatter.ofPattern("HH:mm");
    private final DateTimeFormatter timeFormatter12 = DateTimeFormatter.ofPattern("h:mm a");
    private EditText titleEditText;
    private TextView dateTextView;
    private TextView timeTextView;
    private EditText descriptionEditText;
    private UserDatabaseHelper db;
    private String userName;
    private String eventId;
    private SharedPreferences timePrefs;
    private SharedPreferences notificationPrefs;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_event_edit);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(true);

        ConstraintLayout mainLayout = findViewById(R.id.main);
        ViewCompat.setOnApplyWindowInsetsListener(mainLayout, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        timePrefs = getSharedPreferences(TIME_PREFS_NAME, MODE_PRIVATE);
        notificationPrefs = getSharedPreferences(NOTIFICATION_PREFS_NAME, MODE_PRIVATE);
        db = new UserDatabaseHelper(this);

        titleEditText = findViewById(R.id.titleEditText);
        dateTextView = findViewById(R.id.dateTextView);
        timeTextView = findViewById(R.id.timeTextView);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        Button doneButton = findViewById(R.id.doneButton);
        ImageButton deleteButton = findViewById(R.id.deleteButton);

        Intent intent = getIntent();
        userName = intent.getStringExtra("USER_NAME");
        LocalDate selectedDate = LocalDate.parse(intent.getStringExtra("SELECTED_DATE"));
        eventId = intent.getStringExtra("EVENT_ID");

        boolean is24Hour = timePrefs.getBoolean(IS_24_HOUR, false);
        DateTimeFormatter timeFormatter = is24Hour ? timeFormatter24 : timeFormatter12;

        if (eventId != null) {
            doneButton.setText("Save");
            deleteButton.setVisibility(View.VISIBLE);
            titleEditText.setText(intent.getStringExtra("EVENT_TITLE"));
            try {
                LocalTime time24 = LocalTime.parse(intent.getStringExtra("EVENT_TIME"), timeFormatter24);
                timeTextView.setText(time24.format(timeFormatter));
            } catch (Exception e) {
                timeTextView.setText(intent.getStringExtra("EVENT_TIME"));
            }
            descriptionEditText.setText(intent.getStringExtra("EVENT_DESCRIPTION"));
        } else {
            doneButton.setText("Done");
            deleteButton.setVisibility(View.GONE);
            timeTextView.setText(LocalTime.now().format(timeFormatter));
        }

        dateTextView.setText(selectedDate.format(dateFormatter));

        dateTextView.setOnClickListener(v -> {
            LocalDate currentDate = LocalDate.parse(dateTextView.getText().toString(), dateFormatter);
            int mYear = currentDate.getYear();
            int mMonth = currentDate.getMonthValue() - 1;
            int mDay = currentDate.getDayOfMonth();

            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    (view, year, monthOfYear, dayOfMonth) -> {
                        LocalDate newDate = LocalDate.of(year, monthOfYear + 1, dayOfMonth);
                        dateTextView.setText(newDate.format(dateFormatter));
                        dateTextView.setError(null);
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        });

        timeTextView.setOnClickListener(v -> {
            LocalTime currentTime = LocalTime.parse(timeTextView.getText().toString(), timeFormatter);
            int mHour = currentTime.getHour();
            int mMinute = currentTime.getMinute();

            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    (view, hourOfDay, minute) -> {
                        LocalTime newTime = LocalTime.of(hourOfDay, minute);
                        timeTextView.setText(newTime.format(timeFormatter));
                        timeTextView.setError(null);
                    }, mHour, mMinute, is24Hour);
            timePickerDialog.show();
        });

        doneButton.setOnClickListener(v -> {
            saveEvent();
        });

        deleteButton.setOnClickListener(v -> {
            if (eventId != null) {
                NotificationScheduler.cancelAlarm(this, db, userName, eventId, titleEditText.getText().toString());

                if (db.deleteEvent(eventId) > 0) {
                    Toast.makeText(EventDetails.this, "Event deleted", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(EventDetails.this, "Error deleting event. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void saveEvent() {
        String title = titleEditText.getText().toString().trim();
        String date = dateTextView.getText().toString();
        String timeStr = timeTextView.getText().toString();
        String description = descriptionEditText.getText().toString().trim();

        if (title.isEmpty()) {
            titleEditText.setError("Title is required");
            return;
        }

        if (date.isEmpty()) {
            dateTextView.setError("Date is required");
            return;
        }

        if (timeStr.isEmpty()) {
            timeTextView.setError("Time is required");
            return;
        }

        boolean is24Hour = timePrefs.getBoolean(IS_24_HOUR, false);
        DateTimeFormatter timeFormatter = is24Hour ? timeFormatter24 : timeFormatter12;
        LocalTime time = LocalTime.parse(timeStr, timeFormatter);
        String time24 = time.format(timeFormatter24);

        boolean notificationsOn = notificationPrefs.getBoolean(NOTIFICATIONS_ON_KEY, false);

        if (eventId != null) { // edit event
            if (db.updateEvent(eventId, title, date, time24, description)) {
                if (notificationsOn && NotificationScheduler.checkPermissions(this)) {
                    NotificationScheduler.cancelAlarm(this, db, userName, eventId, title);
                    NotificationScheduler.scheduleAlarm(this, db, userName, eventId, title, date, time24);
                }
                Toast.makeText(EventDetails.this, "Event updated", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(EventDetails.this, "Error updating event. Please try again.", Toast.LENGTH_SHORT).show();
            }
        } else { // new event
            if (db.addEvent(title, date, time24, description, userName)) {
                if (notificationsOn && NotificationScheduler.checkPermissions(this)) {
                    eventId = db.getEventId(userName, title, date, time24);
                    if (eventId != null) {
                        NotificationScheduler.scheduleAlarm(this, db, userName, eventId, title, date, time24);
                    }
                }
                Toast.makeText(EventDetails.this, "Event saved", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(EventDetails.this, "Error saving event. Please try again.", Toast.LENGTH_SHORT).show();
            }
        }

    }
}
