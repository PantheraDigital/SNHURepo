package com.gamingroom.gameauth;

import io.dropwizard.Configuration;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.validator.constraints.*;
import javax.validation.constraints.*;
import javax.validation.Valid;
import io.dropwizard.client.JerseyClientConfiguration;


public class GameAuthConfiguration extends Configuration {

	  @Valid
	  @NotNull
	  private JerseyClientConfiguration jerseyClient = new JerseyClientConfiguration();

	  @JsonProperty("jerseyClient")
	  public JerseyClientConfiguration getJerseyClientConfiguration() {
	    return jerseyClient;
	  }

	  @JsonProperty("jerseyClient")
	  public void setJerseyClientConfiguration(JerseyClientConfiguration jerseyClient) {
	    this.jerseyClient = jerseyClient;
	  }
}